public class Main {
    
    public static void main(String[] args) {
        MainWindow w1 = new MainWindow();
    }

}
